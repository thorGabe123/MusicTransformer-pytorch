import json
import numpy as np
from note import Note

RANGE_NOTE_ON = 128
RANGE_NOTE_OFF = 128
RANGE_TIME_SHIFT = 32
RANGE_VEL = 100
TICKS_PER_RES = 12

START_IDX = {
    'note_on': 0,
    'note_off': RANGE_NOTE_ON,
    'time_shift': RANGE_NOTE_ON + RANGE_NOTE_OFF,
    'velocity': RANGE_NOTE_ON + RANGE_NOTE_OFF + RANGE_TIME_SHIFT,
    'end_of_song': RANGE_NOTE_ON + RANGE_NOTE_OFF + RANGE_TIME_SHIFT + RANGE_VEL
}

START_IDX = {
    'note_on': 0,
    'note_off': RANGE_NOTE_ON,
    'time_shift': RANGE_NOTE_ON + RANGE_NOTE_OFF,
    'velocity': RANGE_NOTE_ON + RANGE_NOTE_OFF + RANGE_TIME_SHIFT,
    'end_of_song': RANGE_NOTE_ON + RANGE_NOTE_OFF + RANGE_TIME_SHIFT + RANGE_VEL
}

def sort_by_second_element(data):
    return sorted(data, key=lambda x: x[1])

def extract_first_elements(sorted_data):
    """Extracts the first element from each sub-list in a sorted list."""
    return [int(x[0]) for x in sorted_data]

def notes2seq(notes):
    event_seq = []
    for n in notes:
        on_event = n["value"] + START_IDX['note_on']
        off_event = on_event + START_IDX['note_off']
        cur_time = n["time"] / TICKS_PER_RES
        end_time = cur_time + n["length"] / TICKS_PER_RES
        time_shift = n["length"] / TICKS_PER_RES + START_IDX['time_shift']
        vel_event = np.floor(n["velocity"] * RANGE_VEL) + START_IDX['velocity']

        event_seq.append([vel_event, cur_time])
        event_seq.append([on_event, cur_time])
        event_seq.append([time_shift, cur_time])
        event_seq.append([off_event, end_time])

    sorted_list = sort_by_second_element(event_seq)
    event_seq = extract_first_elements(sorted_list)
    return event_seq

def seq2notes(event_seq):
    notes = []
    cur_time_ticks = 0
    cur_vel = 0
    for e in event_seq:
        if e in range(START_IDX['note_on'], START_IDX['note_on'] + RANGE_NOTE_ON):
            notes.append(Note(value=e, time=cur_time_ticks, velocity=cur_vel))
        elif e in range(START_IDX['note_off'], START_IDX['note_off'] + RANGE_NOTE_OFF):
            note_off = e - START_IDX['note_off']
            for i in range(len(notes) - 1, -1, -1):
                if notes[i].value == note_off and notes[i].length == -1:
                    notes[i].length = cur_time_ticks - notes[i].time
        elif e in range(START_IDX['time_shift'], START_IDX['time_shift'] + RANGE_TIME_SHIFT):
            cur_time_ticks += (e - START_IDX['time_shift']) * 12
        elif e in range(START_IDX['velocity'], START_IDX['velocity'] + RANGE_VEL):
            cur_vel = (e - START_IDX['velocity']) / RANGE_VEL
        
    return notes

def remove_faulty_event(note_list):
    for n in note_list:
        if n.length != -1:
            note_list.remove(n)
    return note_list

def notes2json(note_list):
    output = []
    # remove_faulty_event(note_list)
    for n in note_list:
        output.append(n.to_dict())
    return output